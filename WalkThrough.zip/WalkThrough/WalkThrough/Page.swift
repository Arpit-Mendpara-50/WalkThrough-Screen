//
//  Page.swift
//  WalkThrough
//
//  Created by Arpit on 11/01/19.
//  Copyright © 2019 Arpit. All rights reserved.
//

import Foundation

struct Page {
    let imageName: String
    let headerText: String
    let bodyText: String
}
